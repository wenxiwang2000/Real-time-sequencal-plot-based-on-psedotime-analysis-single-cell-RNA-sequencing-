#!/usr/bin/env python3
"""
Simple single‑cell analysis pipeline for beetle Malpighian tubule stages.

This command line tool is designed as a light weight alternative to more
opinionated pipelines such as Seurat (R) or the Scanpy based `sc_stage_pipeline.py`.
It follows the same general structure: load 10x data, perform quality control,
normalise and identify highly variable genes, compute principal components,
construct a k‑nearest neighbour graph, cluster cells with the Leiden algorithm
and embed the data with UMAP.  In addition, it can perform a basic
trajectory (pseudotime) analysis using diffusion pseudotime and PAGA.

The tool accepts a single input directory containing `matrix.mtx.gz`,
`barcodes.tsv.gz` and `features.tsv.gz` files exported from Cell Ranger.  It
produces several output files in the specified output folder: QC plots,
UMAP plots coloured by clusters and optionally pseudotime, an AnnData
(`.h5ad`) file containing the processed data, and a table of marker genes
for each cluster.  Optionally you can provide a CSV file mapping cell types
to marker genes; the script will compute average marker expression per
cluster and assign a putative cell type label to each cluster.

Example usage:

    python main.py \
        --input ./filtered_feature_bc_matrix_larva \
        --output results_larva \
        --species beetle \
        --min‑genes 200 --max‑genes 6000 --max‑mt 20 \
        --n‑hvg 3000 --n‑pcs 30 --n‑neighbors 15 --resolution 0.8 \
        --markers markers.csv \
        --pseudotime --root‑cluster 0

See `README.md` in the same folder for a more detailed description and
guidance on parameter tuning.
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional

import numpy as np
import pandas as pd
import scanpy as sc


def parse_marker_file(fname: Optional[str]) -> Dict[str, List[str]]:
    """Parse a marker gene CSV/TSV file into a dictionary.

    The file should have two columns: `cell_type` and `gene`, or it can be
    structured as a CSV where each column header is a cell type and entries
    in that column are markers.  Missing entries should be left blank.

    Examples of accepted formats:

    cell_type,gene
    secondary_cell,tiptop
    secondary_cell,castor
    principal_cell,cut

    or

    secondary_cell,principal_cell,trachea
    tiptop,cut,breathless
    castor,,

    :param fname: path to marker file or None
    :returns: dict mapping cell type to list of marker gene names
    """
    if fname is None:
        return {}
    path = Path(fname)
    if not path.exists():
        raise FileNotFoundError(f"Marker file not found: {path}")
    # try two column format first
    try:
        df = pd.read_csv(path)
    except Exception:
        df = pd.read_csv(path, sep="\t")
    marker_dict: Dict[str, List[str]] = {}
    # if file has exactly two columns and one is named cell_type (case insensitive)
    if df.shape[1] == 2 and any(col.lower() == "cell_type" for col in df.columns):
        cell_col = next(col for col in df.columns if col.lower() == "cell_type")
        gene_col = next(col for col in df.columns if col != cell_col)
        for cell_type, gene in zip(df[cell_col].astype(str), df[gene_col].astype(str)):
            if not gene or pd.isna(gene):
                continue
            marker_dict.setdefault(cell_type.strip(), []).append(gene.strip())
        return marker_dict
    # otherwise treat each column as a cell type
    for cell_type in df.columns:
        markers = [str(g).strip() for g in df[cell_type].dropna().values if str(g).strip()]
        if markers:
            marker_dict[cell_type.strip()] = markers
    return marker_dict


def annotate_with_markers(adata: sc.AnnData, markers: Mapping[str, Iterable[str]], key: str = "marker_score") -> None:
    """Annotate an AnnData object with marker scores and assign cell type labels.

    For each cell type and its list of marker genes, compute the mean
    expression (on the scaled data) across those genes for each cell.
    The per cell type scores are stored in `adata.obs[f"{key}_{cell_type}"]`.
    A best guess of the cell type per cell is stored in `adata.obs[key]`.

    :param adata: processed AnnData (after scaling)
    :param markers: mapping of cell type -> list of marker genes
    :param key: prefix for the score columns and label column
    """
    if not markers:
        return
    # ensure scaled data exist
    if adata.layers.get("scaled") is None:
        raise ValueError("Scaled data not found. Run sc.pp.scale before marker annotation.")
    scaled = adata.layers["scaled"]
    scores = {}
    for cell_type, genes in markers.items():
        valid_genes = [g for g in genes if g in adata.var_names]
        if not valid_genes:
            logging.warning(f"No marker genes found for {cell_type} in dataset")
            continue
        # average scaled expression across genes
        idx = [adata.var_names.get_loc(g) for g in valid_genes]
        # compute mean along axis 1 (cells)
        score = scaled[:, idx].mean(axis=1).A1 if hasattr(scaled[:, idx], 'A1') else np.array(scaled[:, idx].mean(axis=1)).flatten()
        adata.obs[f"{key}_{cell_type}"] = score
        scores[cell_type] = score
    if scores:
        # assign best cell type per cell
        score_df = pd.DataFrame(scores)
        adata.obs[key] = score_df.idxmax(axis=1).values
    else:
        adata.obs[key] = "unknown"


def run_pipeline(
    input_dir: str,
    output_dir: str,
    species: str,
    min_genes: int = 200,
    max_genes: int = 6000,
    min_counts: int = 0,
    max_counts: int = 0,
    max_mt: float = 20.0,
    min_cells_per_gene: int = 3,
    n_hvg: int = 3000,
    n_pcs: int = 30,
    n_neighbors: int = 15,
    resolution: float = 0.8,
    marker_file: Optional[str] = None,
    pseudotime: bool = False,
    root_cluster: Optional[int] = None,
) -> None:
    """Execute the analysis pipeline on a single 10x dataset.

    :param input_dir: path to the folder containing matrix.mtx.gz, barcodes.tsv.gz, features.tsv.gz
    :param output_dir: folder to write results
    :param species: species name used to choose mitochondrial gene prefix
    :param min_genes: minimum genes expressed per cell
    :param max_genes: maximum genes expressed per cell (0 = no filter)
    :param min_counts: minimum UMI counts per cell (0 = no filter)
    :param max_counts: maximum UMI counts per cell (0 = no filter)
    :param max_mt: maximum percent mitochondrial counts per cell
    :param min_cells_per_gene: filter genes expressed in fewer cells
    :param n_hvg: number of highly variable genes to select
    :param n_pcs: number of principal components for PCA
    :param n_neighbors: number of neighbours in KNN graph
    :param resolution: Leiden resolution parameter controlling cluster granularity
    :param marker_file: optional CSV/TSV file mapping cell types to marker genes
    :param pseudotime: if True, perform diffusion pseudotime and PAGA
    :param root_cluster: cluster index to use as pseudotime root
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # ensure figures are saved into the output directory.  Scanpy writes
    # plots into `sc.settings.figdir` when using `save=<str>` on plotting
    # functions.  Create a 'figures' subfolder under the output path and
    # point Scanpy there.  This makes it easy to display figures later.
    figdir = out / 'figures'
    figdir.mkdir(exist_ok=True)
    sc.settings.figdir = str(figdir)

    # read data
    logging.info(f"Reading 10x data from {input_dir}")
    adata = sc.read_10x_mtx(str(input_dir), var_names="gene_symbols", cache=True)
    adata.var_names_make_unique()

    # annotate mitochondrial genes
    if species.lower() in {"human", "homo_sapiens", "mouse", "mus_musculus"}:
        mt_prefix = r"^MT-"
    elif species.lower() in {"drosophila", "dmel", "drosophila_melanogaster", "beetle"}:
        # adapt prefix for beetle; many insect genomes use 'mt:' prefix
        mt_prefix = r"^(mt:|MT:)"
    else:
        mt_prefix = r"^(MT-|mt:|mt-|Mt-|MT:)"
    sc.pp.calculate_qc_metrics(adata, qc_vars=[mt_prefix], inplace=True)
    # the above call will create 'pct_counts_{mt_prefix}' which may not be valid if prefix contains regex
    # for simplicity compute pct_counts_mt manually
    mt_mask = adata.var_names.str.contains(mt_prefix, regex=True)
    adata.obs['pct_counts_mt'] = (adata[:, mt_mask].X.sum(axis=1) / adata.X.sum(axis=1)) * 100

    # basic QC filtering
    sc.pp.filter_cells(adata, min_genes=min_genes)
    if min_counts > 0:
        adata = adata[adata.obs['total_counts'] >= min_counts, :].copy()
    if max_genes > 0:
        adata = adata[adata.obs['n_genes_by_counts'] <= max_genes, :].copy()
    if max_counts > 0:
        adata = adata[adata.obs['total_counts'] <= max_counts, :].copy()
    if max_mt > 0:
        adata = adata[adata.obs['pct_counts_mt'] <= max_mt, :].copy()
    sc.pp.filter_genes(adata, min_cells=min_cells_per_gene)

    # normalisation and log transform
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)

    # highly variable genes
    sc.pp.highly_variable_genes(adata, n_top_genes=n_hvg, flavor="seurat_v3")
    adata = adata[:, adata.var['highly_variable']].copy()

    # scaling
    sc.pp.scale(adata, max_value=10)
    # store scaled layer for marker scoring
    adata.layers['scaled'] = adata.X.copy()

    # PCA
    sc.tl.pca(adata, n_comps=n_pcs, svd_solver='arpack')
    # compute neighbourhood graph
    sc.pp.neighbors(adata, n_neighbors=n_neighbors, n_pcs=n_pcs)

    # clustering
    sc.tl.leiden(adata, resolution=resolution, key_added='leiden')

    # UMAP embedding
    sc.tl.umap(adata)

    # marker gene scoring/annotation
    markers = parse_marker_file(marker_file) if marker_file else {}
    if markers:
        annotate_with_markers(adata, markers, key='predicted_celltype')

    # compute cluster markers
    sc.tl.rank_genes_groups(adata, 'leiden', method='wilcoxon', pts=True)
    # export top 10 markers per cluster to excel
    marker_table_path = out / 'cluster_markers.xlsx'
    with pd.ExcelWriter(marker_table_path) as writer:
        for clus in sorted(adata.obs['leiden'].unique(), key=lambda x: int(x)):
            df = sc.get.rank_genes_groups_df(adata, group=clus).head(50)
            df.to_excel(writer, sheet_name=f'cluster_{clus}', index=False)

    # save AnnData
    adata.write(out / 'adata_processed.h5ad')

    # UMAP plots
    sc.pl.umap(adata, color=['leiden'], save=f'_clusters.png', show=False)
    if markers:
        # convert predicted celltype to string for safe plotting
        sc.pl.umap(adata, color=['predicted_celltype'], save=f'_celltypes.png', show=False)
    # pseudotime
    if pseudotime:
        # compute diffusion map and pseudotime
        sc.tl.diffmap(adata, n_comps=min(50, n_pcs))
        # choose root cell indices from cluster
        if root_cluster is None:
            # choose cluster with lowest mean n_genes_by_counts (often progenitors)
            cluster_means = adata.obs.groupby('leiden')['n_genes_by_counts'].mean()
            root_cluster = int(cluster_means.idxmin())
        # select a single cell from that cluster as root
        root_cell = adata.obs.index[adata.obs['leiden'] == str(root_cluster)][0]
        adata.uns['iroot'] = np.where(adata.obs.index == root_cell)[0][0]
        sc.tl.dpt(adata)
        # run paga to visualise abstract connectivity
        sc.tl.paga(adata, groups='leiden')
        sc.pl.paga(adata, threshold=0.03, show=False, save='_paga.png')
        sc.pl.umap(adata, color=['dpt_pseudotime'], cmap='viridis', save='_pseudotime.png', show=False)

    logging.info(f"Analysis complete. Results saved to {out}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Single cell pipeline for beetle Malpighian tubules")
    parser.add_argument('--input', required=True, help='Path to 10x filtered_feature_bc_matrix directory')
    parser.add_argument('--output', required=True, help='Output directory for results')
    parser.add_argument('--species', default='beetle', help='Species name (affects mito gene detection)')
    parser.add_argument('--min-genes', type=int, default=200, help='Minimum genes detected per cell')
    parser.add_argument('--max-genes', type=int, default=6000, help='Maximum genes detected per cell (0 = ignore)')
    parser.add_argument('--min-counts', type=int, default=0, help='Minimum UMI counts per cell (0 = ignore)')
    parser.add_argument('--max-counts', type=int, default=0, help='Maximum UMI counts per cell (0 = ignore)')
    parser.add_argument('--max-mt', type=float, default=20.0, help='Maximum percent mitochondrial reads per cell')
    parser.add_argument('--min-cells-per-gene', type=int, default=3, help='Filter genes expressed in at least this many cells')
    parser.add_argument('--n-hvg', type=int, default=3000, help='Number of highly variable genes to select')
    parser.add_argument('--n-pcs', type=int, default=30, help='Number of principal components to compute/use')
    parser.add_argument('--n-neighbors', type=int, default=15, help='Number of neighbors for KNN graph')
    parser.add_argument('--resolution', type=float, default=0.8, help='Leiden clustering resolution')
    parser.add_argument('--markers', type=str, default=None, help='CSV/TSV file mapping cell types to marker genes')
    parser.add_argument('--pseudotime', action='store_true', help='Perform diffusion pseudotime and PAGA')
    parser.add_argument('--root-cluster', type=int, default=None, help='Cluster index to use as pseudotime root')
    parser.add_argument('--log-level', default='INFO', help='Logging level (DEBUG, INFO, WARNING, ERROR)')
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper(), 'INFO'), format='%(asctime)s [%(levelname)s] %(message)s')
    run_pipeline(
        input_dir=args.input,
        output_dir=args.output,
        species=args.species,
        min_genes=args.min_genes,
        max_genes=args.max_genes,
        min_counts=args.min_counts,
        max_counts=args.max_counts,
        max_mt=args.max_mt,
        min_cells_per_gene=args.min_cells_per_gene,
        n_hvg=args.n_hvg,
        n_pcs=args.n_pcs,
        n_neighbors=args.n_neighbors,
        resolution=args.resolution,
        marker_file=args.markers,
        pseudotime=args.pseudotime,
        root_cluster=args.root_cluster,
    )


if __name__ == '__main__':
    main()