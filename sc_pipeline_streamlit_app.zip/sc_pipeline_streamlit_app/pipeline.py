"""
Wrapper for the single‑cell analysis pipeline.

This file re‑exports the `run_pipeline` function from the
`sc_pipeline_app` package.  It exists so that the Streamlit app can
import the pipeline without installing the package separately.  When
building the zip file, make sure that `sc_pipeline_app/main.py` is
available in the same directory as this file.
"""

import os
import sys

# Add the parent directory to sys.path so we can import sc_pipeline_app
current_dir = os.path.dirname(__file__)
parent_dir = os.path.abspath(os.path.join(current_dir, os.pardir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from sc_pipeline_app.main import run_pipeline  # type: ignore
except ImportError:
    # Fallback: if sc_pipeline_app is not available, copy of run_pipeline can be placed here
    raise

__all__ = ["run_pipeline"]