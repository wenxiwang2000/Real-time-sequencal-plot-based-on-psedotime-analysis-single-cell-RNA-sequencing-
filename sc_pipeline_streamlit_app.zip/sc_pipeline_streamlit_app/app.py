import os
import sys
import glob
import streamlit as st

# Add the current directory to path so we can import pipeline
sys.path.append(os.path.dirname(__file__))

from pipeline import run_pipeline


def main():
    st.set_page_config(page_title="MT Single Cell Analysis", layout="wide")
    st.title("Malpighian Tubule Single Cell Analysis")

    st.markdown(
        """This application provides a simple interface to run single‑cell
        RNA‑seq analysis on Malpighian tubule data.  Fill in the
        parameters below and click **Run Analysis**.  The analysis will run
        using the underlying Python pipeline and the results (UMAP plots and
        pseudotime plots) will be displayed below."""
    )

    with st.form(key="params_form"):
        input_dir = st.text_input("Input directory", "./filtered_feature_bc_matrix")
        output_dir = st.text_input("Output directory", "./results_streamlit")
        species = st.text_input("Species", "beetle")
        min_genes = st.number_input("Min genes per cell", min_value=0, value=200, step=50)
        max_genes = st.number_input("Max genes per cell (0=no limit)", min_value=0, value=6000, step=100)
        min_counts = st.number_input("Min UMI counts per cell", min_value=0, value=0, step=1000)
        max_counts = st.number_input("Max UMI counts per cell (0=no limit)", min_value=0, value=0, step=1000)
        max_mt = st.number_input("Max percent mitochondrial reads", min_value=0.0, max_value=100.0, value=20.0, step=1.0)
        min_cells_per_gene = st.number_input("Min cells per gene", min_value=1, value=3, step=1)
        n_hvg = st.number_input("Number of HVGs", min_value=100, value=3000, step=100)
        n_pcs = st.number_input("Number of principal components", min_value=10, value=30, step=5)
        n_neighbors = st.number_input("Number of neighbours", min_value=5, value=15, step=1)
        resolution = st.slider("Leiden resolution", min_value=0.1, max_value=2.0, value=0.8, step=0.1)
        marker_file = st.file_uploader(
            "Marker genes file (CSV or TSV)", type=["csv", "tsv"], accept_multiple_files=False
        )
        pseudotime = st.checkbox("Perform pseudotime analysis", value=False)
        root_cluster = st.number_input("Root cluster index (optional)", min_value=0, value=0, step=1)
        submitted = st.form_submit_button("Run Analysis")

    if submitted:
        # ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        marker_path = None
        if marker_file is not None:
            marker_path = os.path.join(output_dir, "uploaded_marker_file.csv")
            # Save uploaded file
            with open(marker_path, "wb") as f:
                f.write(marker_file.getbuffer())
        with st.spinner("Running analysis… this may take a few minutes"):
            try:
                # run the pipeline
                run_pipeline(
                    input_dir=input_dir,
                    output_dir=output_dir,
                    species=species,
                    min_genes=int(min_genes),
                    max_genes=int(max_genes),
                    min_counts=int(min_counts),
                    max_counts=int(max_counts),
                    max_mt=float(max_mt),
                    min_cells_per_gene=int(min_cells_per_gene),
                    n_hvg=int(n_hvg),
                    n_pcs=int(n_pcs),
                    n_neighbors=int(n_neighbors),
                    resolution=float(resolution),
                    marker_file=marker_path,
                    pseudotime=pseudotime,
                    root_cluster=int(root_cluster) if pseudotime else None,
                )
                st.success("Analysis completed successfully!")
            except Exception as e:
                st.error(f"An error occurred: {e}")
        # Display figures
        fig_dir = os.path.join(output_dir, "figures")
        if os.path.isdir(fig_dir):
            imgs = sorted(glob.glob(os.path.join(fig_dir, "*.png")))
            if imgs:
                st.subheader("Figures")
                for img in imgs:
                    st.image(img, caption=os.path.basename(img))
            else:
                st.info("No figures were produced. Check the pipeline output directory.")
        else:
            st.info("Figure directory not found. Check the output path.")


if __name__ == "__main__":
    main()